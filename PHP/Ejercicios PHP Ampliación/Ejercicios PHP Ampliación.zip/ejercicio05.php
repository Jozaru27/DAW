<?php
/**
 * @author Jose Zafrilla Ruiz jozaru27@gmail.com
 * 
 * 5. Realiza un programa que resuelva una ecuación de primer grado (del tipo ax + b = 0)
*/

// Pide dos números por pantalla

echo "Dime un número \n";
$a = readline();
echo "Dime un número \n";
$b = readline();

// Resuelve la ecuación
echo $resultado = -$b/$a . "\n";

?>