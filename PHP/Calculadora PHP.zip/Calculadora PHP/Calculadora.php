<?php /* Calculadora.php */

class Calculadora {

    // Función que suma dos números
    public function sumar($a=0, $b=0){
    return $a + $b;
    }

    // Función que resta dos números
    public function restar($a=0,$b=0){
    return $a - $b;
    }

    // Función que multiplica dos números
    public function multiplicar($a=1,$b=1){
    return $a * $b;
    }

    // Función que divide dos números
    public function dividir($a=1,$b=1){
    return $a / $b;
    }
}
?>