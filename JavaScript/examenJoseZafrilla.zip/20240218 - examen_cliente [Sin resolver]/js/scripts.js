// Autor: Jose Zafrilla - Espero que te lo pases espectacularmente bien corrigiendo el examen :)
// Cuando carga la ventana, se añaden diferentes addEventListeners a los botones - ¿Qué hace cada uno? Explicado en sus funciones correspondientes
window.onload = function() {
    botonEmpezar.addEventListener("click", ocultarModal);  
    botonTodos.addEventListener("click", cargarTodosUsuarios);
    botonAlumnos.addEventListener("click", cargarAlumnos);
    botonProfesores.addEventListener("click", cargarProfes);
    botonAsignaturas.addEventListener("click", cargarAsignaturas);
    botonCerrarAsignaturas.addEventListener("click", cerrarAsignaturas);
}

// FUNCIÓN - Oculta el "bloqueo" cuando se le da al botón de Empezar, añadiendo la clase de ocultar
function ocultarModal(){
    titulo.classList.add("ocultar"); // Oculta la imagen
    botonEmpezar.classList.add("ocultar"); // Oculta el botón
    protector.classList.add("ocultar"); // Oculta el protector

    botonera = document.querySelector("#botonera"); // Todo esto - Recupera la imagen y la sitúa a la izquierda de la botonera
    divLogo = document.getElementById("logo");
    botonera.appendChild(divLogo);
    divLogo.classList.remove("ocultar");
}

// FUNCIÓN - Cargar todos los usuarios de la API
async function cargarTodosUsuarios() {
    let url = "http://diegogarcia.ddns.net/usuarios"; // url general para obtener los usuarios
    cartas.innerHTML = ""; // limpia el contenido para que no se acumule

    await fetch(url) // fetch
    .then(response => response.json())
    .then(data =>{
        datosAPI = data; // guarda la info obtenida del json en una variable
        console.log(data);
        
        for (datosPersona of datosAPI){ // por cada uno de los datos, crea el div donde se almacenan las cosas, y de él cuelga un div img, nombre, email y rol, con sus datos correspondientes
            let cartaDiv = document.createElement("div");
            cartaDiv.classList.add("carta");
            
            let imgPersona = document.createElement("img");
            imgPersona.src = datosPersona.foto;

            let nombrePersona = document.createElement("div");
            nombrePersona.classList.add("nombre");
            nombrePersona.innerText = datosPersona.nombre;

            let emailPersona = document.createElement("div");
            emailPersona.classList.add("email");
            emailPersona.innerText = datosPersona.correo;

            let rol = document.createElement("div");
            rol.classList.add("rol");
            if (datosPersona.rol == "Alumno"){ // Depende de si el rol del usuario es alumno o profesor, asignará una clase y mostrará una inicial u otra
                rol.classList.add("alumno");
                rol.innerText = "A";
            } else {
                rol.classList.add("profesor");
                rol.innerText = "P";
            }

            cartas.appendChild(cartaDiv);   // Cuelga las cosas para mostrarlas
            cartaDiv.appendChild(imgPersona);
            cartaDiv.appendChild(nombrePersona);
            cartaDiv.appendChild(emailPersona);
            cartaDiv.appendChild(rol);
            
            cartaDiv.addEventListener("click", mostrarInfo()); // LLama a la función de mostrar info para cuando se clique a las imágenes
        }
    })
}

async function cargarAlumnos() {
    let url = "http://diegogarcia.ddns.net/usuarios/Alumno"; // url de alumno en especifico para obtener los datos de alumnos
    cartas.innerHTML = ""; // limpia el contenido para que no se acumule

    await fetch(url)
    .then(response => response.json())
    .then(data =>{
        datosAPI = data;
        console.log(data);
        
        // Hace lo mismo que la función anterior, solo que como ya sabemos que es para alumnos, no tiene sentido poner la lógica de los roles
        for (datosPersona of datosAPI){
            let cartaDiv = document.createElement("div");
            cartaDiv.classList.add("carta");
            
            let imgPersona = document.createElement("img");
            imgPersona.src = datosPersona.foto;

            let nombrePersona = document.createElement("div");
            nombrePersona.classList.add("nombre");
            nombrePersona.innerText = datosPersona.nombre;

            let emailPersona = document.createElement("div");
            emailPersona.classList.add("email");
            emailPersona.innerText = datosPersona.correo;

            let rol = document.createElement("div");
            rol.classList.add("rol");
            rol.classList.add("alumno");
            rol.innerText = "A";

            cartas.appendChild(cartaDiv);
            cartaDiv.appendChild(imgPersona);
            cartaDiv.appendChild(nombrePersona);
            cartaDiv.appendChild(emailPersona);
            cartaDiv.appendChild(rol);
            
            cartaDiv.addEventListener("click", mostrarInfo()); // LLama a la función de mostrar info para cuando se clique a las imágenes
        }
    })
}

async function cargarProfes() {
    let url = "http://diegogarcia.ddns.net/usuarios/Profesor"; // url de profes en especifico para obtener los datos de los profesores
    cartas.innerHTML = ""; // limpia el contenido para que no se acumule

    await fetch(url)
    .then(response => response.json())
    .then(data =>{
        datosAPI = data;
        console.log(data);
        
        // Hace lo mismo que la función anterior, solo que como ya sabemos que es para profesores, no tiene sentido poner la lógica de los roles
        for (datosPersona of datosAPI){
            let cartaDiv = document.createElement("div");
            cartaDiv.classList.add("carta");
            
            let imgPersona = document.createElement("img");
            imgPersona.src = datosPersona.foto;

            let nombrePersona = document.createElement("div");
            nombrePersona.classList.add("nombre");
            nombrePersona.innerText = datosPersona.nombre;

            let emailPersona = document.createElement("div");
            emailPersona.classList.add("email");
            emailPersona.innerText = datosPersona.correo;

            let rol = document.createElement("div");
            rol.classList.add("rol");
            rol.classList.add("profesor");
            rol.innerText = "P";

            cartas.appendChild(cartaDiv);
            cartaDiv.appendChild(imgPersona);
            cartaDiv.appendChild(nombrePersona);
            cartaDiv.appendChild(emailPersona);
            cartaDiv.appendChild(rol);
            
            cartaDiv.addEventListener("click", mostrarInfo()); // LLama a la función de mostrar info para cuando se clique a las imágenes
        }
    })
}

// FUNCIÓN - Al clicar las cartas, cargará la información correspondiente, dependiendo de si es alumno o profesor, y lo muestra en la propia carta
async function mostrarInfo(){ 
    // let divAsignatura = document.createElement("div");
    // divAsignatura.setAttribute("id", "id.asignatura");
    // div
}

async function cargarAsignaturas(){
    asignaturasDiv = document.getElementById("asignaturas"); // lógica para cargar el modal de asignaturas, mostrar y borrar, con click al botón
    asignaturasDiv.classList.remove("ocultar");
    protector.classList.remove("ocultar");
    tabla = document.getElementById("tablaAsignatura")
    let TBody = tabla.createTBody(); // crea la tabla

    url = "http://diegogarcia.ddns.net/asignaturas"; // fetch en concreto para asignaturas

    await fetch(url)
    .then(response=>response.json())
    .then(data=>{
        asignaturas = data;

        // dentro de la tabla, crea una row. a cada row se le inserta un campo, con sus respectivas clases
        // se crea un text node con al información correspondiente y se cuelga del campo
        for (datosAsignatura of asignaturas){
            let row = TBody.insertRow();
            let campo1 = row.insertCell();
            campo1.classList.add("celdaas");
            let campo2 = row.insertCell();
            campo2.classList.add("celdaho");
            let campo3 = row.insertCell();
            campo3.classList.add("celdapr");
            let texto1 = document.createTextNode(datosAsignatura.titulo);
            let texto2 = document.createTextNode(datosAsignatura.horas);
            let texto3 = document.createTextNode(datosAsignatura.profesor);
            campo1.appendChild(texto1);
            campo2.appendChild(texto2);
            campo3.appendChild(texto3);

        }
    });



}

// FUNCIÓN - Cierra el modal de asignatura (se le llama desde el botón de cerrar)
function cerrarAsignaturas(){
    asignaturasDiv = document.getElementById("asignaturas"); // lógica para borrar 
    asignaturasDiv.classList.add("ocultar");
    protector.classList.add("ocultar");
}